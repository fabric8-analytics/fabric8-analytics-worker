for i in $(ls *.asdqwe); do
    some command $i
done

cp $file $target

[ $foo = "bar" ]

