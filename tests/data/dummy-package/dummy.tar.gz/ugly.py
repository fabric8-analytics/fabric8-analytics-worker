
def x():
  pass

if name == main:
	f()

def f(x=[]):
  if x == None:
    x = 1

