#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ######################################################################
# Copyright (C) 2016-2018  Fridolin Pokorny, fridolin.pokorny@gmail.com
# This file is part of Selinon project.
# ######################################################################

from selinon import SelinonTask


class Task1(SelinonTask):
    def run(self, node_args):
        pass


class task2(SelinonTask):
    # class name left lowercase intentionally
    def run(self, node_args):
        pass


class task3(SelinonTask):
    # class name left lowercase intentionally
    def run(self, node_args):
        pass
