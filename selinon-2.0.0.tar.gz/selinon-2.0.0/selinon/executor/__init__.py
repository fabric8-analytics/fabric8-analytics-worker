#!/usr/bin/env python3
"""A primitive executor for Selinon."""

from .executor import Executor
