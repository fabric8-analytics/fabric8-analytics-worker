#!/usr/bin/env python3
"""PostgreSQL Selinon storage adapter."""

from .adapter import PostgreSQL
from .models import Result
