#!/usr/bin/env python3
"""Various pre-implemented database adapters for Selinon for storage usage."""
