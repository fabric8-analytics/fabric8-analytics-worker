#!/bin/env python3
# pragma: no cover


def argsIsStr(node_args):
    return isinstance(node_args, str)
