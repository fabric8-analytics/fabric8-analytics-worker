#!/bin/env python3
# pragma: no cover


def isFloat(message):
    return isinstance(message, float)
