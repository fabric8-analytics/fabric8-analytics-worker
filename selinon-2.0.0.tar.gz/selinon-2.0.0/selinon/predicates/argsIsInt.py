#!/bin/env python3
# pragma: no cover


def argsIsInt(node_args):
    return isinstance(node_args, int)
