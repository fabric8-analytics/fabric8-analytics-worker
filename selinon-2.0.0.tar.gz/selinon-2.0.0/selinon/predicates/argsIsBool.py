#!/bin/env python3
# pragma: no cover


def argsIsBool(node_args):
    return isinstance(node_args, bool)
