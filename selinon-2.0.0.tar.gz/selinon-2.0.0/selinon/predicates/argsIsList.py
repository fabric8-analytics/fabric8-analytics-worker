#!/bin/env python3
# pragma: no cover


def argsIsList(node_args):
    return isinstance(node_args, list)
