#!/bin/env python3
# pragma: no cover


def argsEmpty(node_args):
    return bool(node_args)
