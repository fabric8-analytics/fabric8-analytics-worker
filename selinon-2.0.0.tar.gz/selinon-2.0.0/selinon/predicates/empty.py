#!/bin/env python3
# pragma: no cover


def empty(message):
    return bool(message)
