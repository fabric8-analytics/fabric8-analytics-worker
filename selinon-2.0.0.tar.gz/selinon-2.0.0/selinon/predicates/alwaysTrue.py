#!/bin/env python3
# pragma: no cover


def alwaysTrue():
    return True
