#!/bin/env python3
# pragma: no cover


def isList(message):
    return isinstance(message, list)
