#!/bin/env python3
# pragma: no cover


def isNone(message):
    return message is None
