#!/bin/env python3
# pragma: no cover


def argsIsNone(node_args):
    return node_args is None
