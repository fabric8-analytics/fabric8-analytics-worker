#!/bin/env python3
# pragma: no cover


def argsIsFloat(node_args):
    return isinstance(node_args, float)
