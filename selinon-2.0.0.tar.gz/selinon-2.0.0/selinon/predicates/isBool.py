#!/bin/env python3
# pragma: no cover


def isBool(message):
    return isinstance(message, bool)
