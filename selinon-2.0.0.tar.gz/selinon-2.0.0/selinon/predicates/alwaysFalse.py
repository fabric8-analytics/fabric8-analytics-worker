#!/bin/env python3
# pragma: no cover


def alwaysFalse():
    return False
