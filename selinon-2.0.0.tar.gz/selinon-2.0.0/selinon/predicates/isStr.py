#!/bin/env python3
# pragma: no cover


def isStr(message):
    return isinstance(message, str)
