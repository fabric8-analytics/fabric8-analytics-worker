#!/bin/env python3
# pragma: no cover


def isInt(message):
    return isinstance(message, int)
