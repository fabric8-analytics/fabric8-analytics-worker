#!/usr/bin/env python3
"""Migrations of configuration files."""

from .migrator import Migrator
from .tainted_flow_strategy import TaintedFlowStrategy
